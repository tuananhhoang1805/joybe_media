<?php
    require('header.php');
?>
<h3>CẬP NHẬP SÁCH</h3>
<form method="post" action="" enctype="multipart/form-data" class="form-horizontal">
    <div class="form-group">
        <label class="control-label col-sm-2" for="txtTitle" >Tựa sách</label>
        <input type="text" name="txtTitle" value="<?php if(isset($_GET['title'])) echo $_GET['title']; ?>"/>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="txtPubDate" >Năm xuất bản</label>
        <input type="text" name="txtPubDate" value="<?php if(isset($_GET['year'])) echo $_GET['year']; ?>"/>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="Img">Hình sách</label>
        <input type="file" name="Img" value="<?php if(isset($_GET['img'])) echo "Image/".$_GET['img']; ?>"/>
    </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
            <input type="submit" name="Update" value="Update" class="btn btn-default"/>
         </div>
    </div>
</form>
<?php 
    include "DbProcess.php";
    use DB\DbProcess;
    $id = "";
    if (isset($_POST['Update'],$_POST['txtTitle'],$_POST['txtPubDate'],$_GET['id']))
    {
        $id = $_GET['id'];
        $title = $_POST['txtTitle'];
        $year = $_POST['txtPubDate'];
        
        if (isset($_FILES['Img']))
        {
            if ($_FILES['Img']['error'] > 0)
            {
                echo 'File Upload Bị Lỗi';
            }
            else
            {
                move_uploaded_file($_FILES['Img']['tmp_name'],
                './Images/'.$_FILES['Img']['name']);
                $sql ="UPDATE  tb_book set Title = '".$title."', PubDate = '".$year."', Image = '".$_FILES['Img']['name']."'
                 WHERE BookId =".$id;
                DbProcess::Update($sql);
            }
        }
        else{
        echo 'please choose a file' ;
        }
    }
?>
<?php
    require('footer.php');
?>